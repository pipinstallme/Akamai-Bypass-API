<?php
$output = shell_exec('java -jar AkamaiSensordata.jar'); // the public akamai bypass.
echo $output;
?>
